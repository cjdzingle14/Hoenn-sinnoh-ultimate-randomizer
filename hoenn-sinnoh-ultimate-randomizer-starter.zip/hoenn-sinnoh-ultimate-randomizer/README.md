# Hoenn × Sinnoh Ultimate Randomizer

A fan-made Pokémon GBA ROM-hack project planned on top of [pokeemerald-expansion](https://github.com/rh-hideout/pokeemerald-expansion).

**Status:** Initial source scaffold only. This is not a playable ROM and does not include the upstream engine or copyrighted game assets.

## Agreed game design
- Hoenn and Sinnoh are both accessible; neither region is the mandatory first region.
- Gym teams scale with player progression.
- Starter selection is randomized from an eligible pool.
- Legendary Pokémon may be distributed across eligible wild encounter locations.
- Mega Evolution is included, using the official Mega-capable species/forms supported by the pinned engine version.
- Randomization is seed-based and reproducible.

## Project structure
- `config/` — default rules and randomizer settings.
- `docs/` — design, architecture, and build notes.
- `tools/` — standalone deterministic randomizer utilities.
- `src/` — reserved for hack-specific C source after the engine baseline is integrated.
- `tests/` — automated tests for standalone tools.

## Next required step
Clone the upstream `pokeemerald-expansion` project separately, follow its current build instructions, and verify an unmodified build. Then integrate this project's source changes against a pinned upstream commit. Do not place a commercial ROM or extracted copyrighted assets in this repository.

See `docs/IMPLEMENTATION_PLAN.md` before starting engine integration.
