# Game Design

## World structure: both-open
Hoenn and Sinnoh are available from the beginning through a deliberate in-game travel mechanism (for example, a port/airport hub). The player chooses the order of regional exploration. Region access must not be tied to completing the other region's League.

## Shared progression
Use a global progression score derived from durable milestones rather than current party level alone. Candidate inputs:
- number of Gym Badges earned across both regions;
- major story milestones completed;
- regional League completion flags.

The score should be monotonic: optional detours and party changes must not reduce it. Gym roster selection uses this score to select a configured tier, then builds a legal team for that tier.

## Gym scaling
Scaling should preserve each Gym's identity while changing team size, levels, moves, held items, and evolution stage by tier. Gym leaders should not scale during a battle. Store the chosen tier at battle setup for deterministic behavior.

## Starter randomization
Select three distinct eligible species from the configured pool using the run seed and a dedicated randomization stream. The starter pool must exclude invalid, unobtainable, or unsupported species. Starter selection should not change when unrelated encounter settings are changed.

## Legendary distribution
Legendary species can be assigned to eligible wild encounter slots across both regions. Use configurable rarity weights, duplicate policy, and a protection list for story-critical encounters. Keep required plot encounters intact unless a future setting explicitly opts into replacing them.

## Mega Evolution
Mega Evolution is a feature requirement. Use only the mechanics, item handling, species forms, and battle hooks supported by the selected pokeemerald-expansion revision. Verify each Mega-capable species, stone, ability, and form transition against that revision; do not assume upstream APIs remain stable.

## Randomizer reproducibility
A seed plus a versioned settings document must reproduce the same randomized world. Use independent deterministic streams for starters, ordinary encounters, legendary placement, and other systems so adding a random draw to one subsystem does not reshuffle all others.
