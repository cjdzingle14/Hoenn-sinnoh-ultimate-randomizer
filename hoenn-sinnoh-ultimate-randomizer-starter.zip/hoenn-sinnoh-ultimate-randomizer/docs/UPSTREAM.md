# Upstream Engine Record

Planned base: `rh-hideout/pokeemerald-expansion`

No upstream commit is pinned yet. Before engine-specific code is written:
1. Clone the upstream repository.
2. Review its current license and build instructions.
3. Build it unchanged.
4. Record the exact commit SHA, compiler, and required tools here.

Do not guess API names or copy implementation details from a different revision. Engine integration must target the recorded revision.
